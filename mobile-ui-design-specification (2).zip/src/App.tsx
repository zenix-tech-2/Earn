import { useState, useEffect, Fragment } from 'react'
import { HomeIcon, WalletIcon, UsersIcon, ChatBubbleLeftRightIcon, UserIcon, ChevronLeftIcon, XMarkIcon, LanguageIcon, Cog6ToothIcon, ArrowUpIcon, ArrowDownIcon, ClipboardDocumentIcon, BellIcon, QuestionMarkCircleIcon, InformationCircleIcon, ShieldCheckIcon, DocumentTextIcon, PhoneIcon, EnvelopeIcon, TrophyIcon, GiftIcon, PlayIcon, VideoCameraIcon, BanknotesIcon, GlobeAltIcon, ArrowsRightLeftIcon, ChartBarIcon, MagnifyingGlassIcon, PaperAirplaneIcon, ClockIcon, PhotoIcon, FilmIcon, DocumentIcon } from '@/components/icons'
import { translations, Language } from '@/i18n'
import { AuthProvider, useAuth } from '@/context/AuthContext'
import { supabase } from '@/lib/supabase'
import { initPWA, promptInstall } from '@/lib/pwa'
import { runAiCheck } from '@/lib/aiVerification'

type Page = 'auth' | 'home' | 'deposit' | 'withdraw' | 'affiliate' | 'account' | 'adminPanel' | 'adminProducts' | 'adminApiKeys' | 'adminApproveUsers' | 'settings' | 'editProfile'
type Tab = 'home' | 'affiliate' | 'updates' | 'chat' | 'account'

const COUNTRIES = [
  { code: 'NG', name: 'Nigeria', currency: 'NGN', symbol: '₦' },
  { code: 'GH', name: 'Ghana', currency: 'GHS', symbol: 'GH₵' },
  { code: 'KE', name: 'Kenya', currency: 'KES', symbol: 'KSh' },
  { code: 'ZA', name: 'South Africa', currency: 'ZAR', symbol: 'R' },
  { code: 'US', name: 'United States', currency: 'USD', symbol: '$' },
  { code: 'GB', name: 'United Kingdom', currency: 'GBP', symbol: '£' },
]

const PRODUCT_TYPES = [
  { value: 'ebook', label: 'Ebook / PDF', icon: '📚' },
  { value: 'file', label: 'Digital File', icon: '📄' },
  { value: 'social_account', label: 'Social Media Account', icon: '👤' },
  { value: 'source_code', label: 'Source Code / Script', icon: '💻' },
  { value: 'course', label: 'Online Course', icon: '🎓' },
  { value: 'other', label: 'Other', icon: '📦' },
]

const CATEGORIES = [
  { value: 'Finance', label: 'Finance', icon: '💰' },
  { value: 'Marketing', label: 'Marketing', icon: '📈' },
  { value: 'Social Media', label: 'Social Media', icon: '📱' },
  { value: 'Education', label: 'Education', icon: '🎓' },
  { value: 'Technology', label: 'Technology', icon: '💻' },
  { value: 'Other', label: 'Other', icon: '⭐' },
]

function AppContent() {
  const { user, loading, signIn, signUp, signInWithGoogle, signOut, resetPassword, updateProfile } = useAuth()
  const [lang, setLang] = useState<Language>('en')
  const [page, setPage] = useState<Page>('auth')
  const [tab, setTab] = useState<Tab>('home')
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [authMode, setAuthMode] = useState<'login' | 'signup' | 'forgot'>('login')
  const [authForm, setAuthForm] = useState({ email: '', password: '', name: '', username: '', phone: '', country: 'NG' })
  const [showPassword, setShowPassword] = useState(false)
  const [pwaInstallable, setPwaInstallable] = useState(false)
  const [products, setProducts] = useState<any[]>([])
  const [pendingPayments, setPendingPayments] = useState<any[]>([])
  const [loadingState, setLoadingState] = useState(false)
  const [toast, setToast] = useState('')
  const [showTypeSheet, setShowTypeSheet] = useState(false)
  const [showCategorySheet, setShowCategorySheet] = useState(false)
  const [productForm, setProductForm] = useState({ title: '', description: '', type: '', category: '', platform: '', cred1_label: 'Email', cred2_label: 'Password', slots: [{ cred1: '', cred2: '' }] })
  const [profileForm, setProfileForm] = useState({ name: '', username: '', phone: '', country: 'NG' })
  const [depositMethod, setDepositMethod] = useState<'chariow' | 'manual'>('chariow')
  const [proofFile, setProofFile] = useState<File | null>(null)

  const t = translations[lang]
  const tx = (key: string) => t[key as keyof typeof t] || key
  const userCountry = COUNTRIES.find(c => c.code === user?.country) || COUNTRIES[0]
  const isAdmin = user?.is_admin || user?.email === 'honestansah@gmail.com'

  useEffect(() => {
    document.body.style.overscrollBehavior = 'none'
    initPWA()
    const handleInstallable = () => setPwaInstallable(true)
    window.addEventListener('pwa-installable', handleInstallable)
    return () => window.removeEventListener('pwa-installable', handleInstallable)
  }, [])

  useEffect(() => {
    if (user) {
      setPage('home')
      loadData()
    } else if (!loading) {
      setPage('auth')
    }
  }, [user, loading])

  const loadData = async () => {
    const { data: productsData } = await supabase.from('products').select('*').order('created_at', { ascending: false })
    if (productsData) setProducts(productsData)
    if (isAdmin) {
      const { data: pending } = await supabase.from('pending_payments').select('*').eq('status', 'pending')
      if (pending) setPendingPayments(pending)
    }
  }

  const showToast = (msg: string) => { setToast(msg); setTimeout(() => setToast(''), 3000) }
  const navigate = (p: Page, currentTab?: Tab) => { setPage(p); if (currentTab) setTab(currentTab) }

  const handleAuth = async () => {
    setLoadingState(true)
    try {
      if (authMode === 'login') {
        const { error } = await signIn(authForm.email, authForm.password)
        if (error) showToast('Login failed: ' + error.message)
      } else if (authMode === 'signup') {
        const { error } = await signUp(authForm.email, authForm.password, {
          name: authForm.name, username: authForm.username, phone: authForm.phone, country: authForm.country
        })
        if (error) showToast('Signup failed: ' + error.message)
        else showToast('Check your email to confirm signup')
      } else {
        const { error } = await resetPassword(authForm.email)
        if (error) showToast('Error: ' + error.message)
        else showToast('Password reset email sent')
      }
    } finally { setLoadingState(false) }
  }

  const handleGoogleAuth = async () => {
    setLoadingState(true)
    const { error } = await signInWithGoogle()
    if (error) showToast('Google sign-in failed: ' + error.message)
    setLoadingState(false)
  }

  const handleProfileUpdate = async () => {
    setLoadingState(true)
    const { error } = await updateProfile(profileForm)
    if (error) showToast('Update failed')
    else { showToast('Profile updated'); navigate('account') }
    setLoadingState(false)
  }

  const handleInstallPWA = async () => {
    const installed = await promptInstall()
    if (installed) showToast('App installed!')
  }

  const handlePaymentSubmit = async () => {
    if (!user || !proofFile) return showToast('Upload payment proof')
    setLoadingState(true)
    const fileName = `${user.id}/${Date.now()}-${proofFile.name}`
    const { error: uploadError } = await supabase.storage.from('payment-proofs').upload(fileName, proofFile)
    if (uploadError) { showToast('Upload failed'); setLoadingState(false); return }
    const { data: urlData } = supabase.storage.from('payment-proofs').getPublicUrl(fileName)
    const { error } = await supabase.from('pending_payments').insert({
      user_id: user.id, amount: 2300, method: depositMethod, proof_url: urlData.publicUrl, status: 'pending'
    })
    if (error) showToast('Submission failed')
    else { showToast('Payment submitted for verification'); setProofFile(null); navigate('home') }
    setLoadingState(false)
  }

  const handleAiCheck = async (paymentId: string) => {
    setLoadingState(true)
    const result = await runAiCheck(paymentId)
    showToast(`AI: ${result.confidence}% - ${result.notes}`)
    if (result.confidence >= 85) showToast('Auto-approved by AI')
    setLoadingState(false)
  }

  const addAccountSlot = () => setProductForm(prev => ({ ...prev, slots: [...prev.slots, { cred1: '', cred2: '' }] }))
  const removeAccountSlot = (index: number) => setProductForm(prev => ({ ...prev, slots: prev.slots.filter((_, i) => i !== index) }))

  const handleProductSubmit = async () => {
    if (!productForm.title || !productForm.type || !productForm.category) return showToast('Fill all required fields')
    const { error } = await supabase.from('products').insert({
      title: productForm.title, description: productForm.description, type: productForm.type,
      category: productForm.category, platform: productForm.platform, is_free: true, created_by: user?.id
    })
    if (error) showToast('Failed to create product')
    else {
      showToast('Product created')
      setProductForm({ title: '', description: '', type: '', category: '', platform: '', cred1_label: 'Email', cred2_label: 'Password', slots: [{ cred1: '', cred2: '' }] })
      loadData()
    }
  }

  const Drawer = () => (
    <div className={`fixed inset-0 z-50 ${drawerOpen ? 'block' : 'hidden'}`}>
      <div className="absolute inset-0 bg-black/40" onClick={() => setDrawerOpen(false)} />
      <div className="absolute left-0 top-0 bottom-0 w-72 bg-white shadow-2xl flex flex-col">
        <div className="h-16 bg-gray-900 flex items-center justify-between px-4">
          <span className="text-white font-black text-xl">EARNIZI</span>
          <button onClick={() => setDrawerOpen(false)} className="text-white/70"><XMarkIcon className="w-6 h-6" /></button>
        </div>
        <div className="flex-1 overflow-y-auto py-2">
          {!user?.is_paid ? (
            <button onClick={() => { navigate('home'); setDrawerOpen(false) }} className="w-full flex items-center gap-3 px-5 py-3 bg-amber-50 text-amber-700">
              <TrophyIcon className="w-5 h-5" /><span className="text-sm font-medium">Unlock Access</span>
            </button>
          ) : (
            <>
              {[{ page: 'home', icon: HomeIcon, label: 'Home' }, { page: 'deposit', icon: WalletIcon, label: 'Deposit' }, { page: 'withdraw', icon: BanknotesIcon, label: 'Withdraw' }, { page: 'affiliate', icon: UsersIcon, label: 'Affiliate' }, { page: 'products', icon: GiftIcon, label: 'Products' }, { page: 'settings', icon: Cog6ToothIcon, label: 'Settings' }].map(item => (
                <button key={item.page} onClick={() => { navigate(item.page as Page); setDrawerOpen(false) }} className="w-full flex items-center gap-3 px-5 py-3 hover:bg-gray-50">
                  <item.icon className="w-5 h-5 text-gray-500" /><span className="text-sm font-medium text-gray-700">{item.label}</span>
                </button>
              ))}
              {isAdmin && (
                <>
                  <div className="px-4 py-2 text-xs font-bold text-gray-400 uppercase mt-2">Admin</div>
                  <button onClick={() => { navigate('adminPanel'); setDrawerOpen(false) }} className="w-full flex items-center gap-3 px-5 py-3 hover:bg-gray-50">
                    <ChartBarIcon className="w-5 h-5 text-gray-500" /><span className="text-sm font-medium text-gray-700">Admin Panel</span>
                  </button>
                </>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  )

  const TopBar = () => (
    <div className="fixed top-0 left-0 right-0 h-14 bg-white z-40 flex items-center justify-between px-4 border-b border-gray-100">
      {user?.is_paid ? <button onClick={() => setDrawerOpen(true)} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-gray-50"><HomeIcon className="w-6 h-6 text-gray-700" /></button> : <div className="w-10" />}
      <span className="text-lg font-black tracking-wider text-gray-900">EARNIZI</span>
      <div className="flex items-center gap-1">
        {user ? <button onClick={() => navigate('account')} className="w-10 h-10 flex items-center justify-center rounded-full bg-gray-900 text-white"><UserIcon className="w-5 h-5" /></button> : <button onClick={() => setAuthMode('login')} className="text-xs font-bold text-gray-900 bg-amber-400 px-3 py-1.5 rounded-full">Login</button>}
      </div>
    </div>
  )

  const BottomTabs = () => {
    if (!user?.is_paid) return null
    const tabs = [
      { id: 'home', icon: HomeIcon, label: 'Home' },
      { id: 'affiliate', icon: UsersIcon, label: 'Affiliate' },
      { id: 'updates', icon: VideoCameraIcon, label: 'Updates' },
      { id: 'chat', icon: ChatBubbleLeftRightIcon, label: 'Chat' },
      { id: 'account', icon: UserIcon, label: 'Account' },
    ]
    return (
      <div className="fixed bottom-0 left-0 right-0 h-16 bg-white z-40 border-t border-gray-100 flex items-center justify-around px-1">
        {tabs.map(t => {
          const active = tab === t.id
          return (
            <button key={t.id} onClick={() => { setTab(t.id as Tab); setPage(t.id as Page) }} className={`flex flex-col items-center justify-center w-16 ${active ? 'bg-amber-400' : ''} rounded-2xl`}>
              <t.icon className={`w-6 h-6 ${active ? 'text-gray-900' : 'text-gray-400'}`} />
              <span className={`text-[10px] font-bold mt-1 ${active ? 'text-gray-900' : 'text-gray-400'}`}>{t.label}</span>
            </button>
          )
        })}
      </div>
    )
  }

  const PageContainer = ({ children }: { children: any }) => (
    <div className="fixed top-14 bottom-16 left-0 right-0 overflow-y-auto bg-gray-50" style={{ WebkitOverflowScrolling: 'touch' }}>
      <div className="max-w-lg mx-auto px-4 py-4">{children}</div>
    </div>
  )

  const Toast = () => toast ? <div className="fixed top-20 left-4 right-4 z-50 bg-gray-900 text-white text-sm font-medium py-3 px-4 rounded-2xl shadow-lg">{toast}</div> : null

  const AuthPage = () => (
    <div className="fixed inset-0 bg-gray-50 overflow-y-auto">
      <div className="max-w-lg mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <div className="text-5xl mb-3">💰</div>
          <h1 className="text-3xl font-black text-gray-900">EARNIZI</h1>
          <p className="text-sm text-gray-500 mt-1">earn.sellizi.store</p>
        </div>
        <div className="bg-white rounded-2xl p-5 border border-gray-100">
          <h2 className="text-lg font-bold text-gray-900 mb-4 text-center">{authMode === 'login' ? 'Login' : authMode === 'signup' ? 'Sign Up' : 'Reset Password'}</h2>
          <div className="space-y-3">
            {authMode === 'signup' && (
              <>
                <input type="text" value={authForm.name} onChange={e => setAuthForm({...authForm, name: e.target.value})} placeholder="Full Name" className="w-full bg-gray-50 rounded-xl py-2.5 px-3 text-sm outline-none border border-gray-100" />
                <input type="text" value={authForm.username} onChange={e => setAuthForm({...authForm, username: e.target.value})} placeholder="Username" className="w-full bg-gray-50 rounded-xl py-2.5 px-3 text-sm outline-none border border-gray-100" />
                <input type="tel" value={authForm.phone} onChange={e => setAuthForm({...authForm, phone: e.target.value})} placeholder="Phone Number" className="w-full bg-gray-50 rounded-xl py-2.5 px-3 text-sm outline-none border border-gray-100" />
                <select value={authForm.country} onChange={e => setAuthForm({...authForm, country: e.target.value})} className="w-full bg-gray-50 rounded-xl py-2.5 px-3 text-sm outline-none border border-gray-100">
                  {COUNTRIES.map(c => <option key={c.code} value={c.code}>{c.name} ({c.currency})</option>)}
                </select>
              </>
            )}
            <input type="email" value={authForm.email} onChange={e => setAuthForm({...authForm, email: e.target.value})} placeholder="Email" className="w-full bg-gray-50 rounded-xl py-2.5 px-3 text-sm outline-none border border-gray-100" />
            {authMode !== 'forgot' && (
              <div className="relative">
                <input type={showPassword ? 'text' : 'password'} value={authForm.password} onChange={e => setAuthForm({...authForm, password: e.target.value})} placeholder="Password" className="w-full bg-gray-50 rounded-xl py-2.5 px-3 pr-10 text-sm outline-none border border-gray-100" />
                <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 text-xs">{showPassword ? 'Hide' : 'Show'}</button>
              </div>
            )}
            <button onClick={handleAuth} disabled={loadingState} className="w-full bg-gray-900 text-white rounded-2xl py-3.5 font-bold text-sm disabled:opacity-50">
              {loadingState ? 'Processing...' : authMode === 'login' ? 'Login' : authMode === 'signup' ? 'Sign Up' : 'Send Reset Link'}
            </button>
            {authMode !== 'forgot' && (
              <button onClick={handleGoogleAuth} disabled={loadingState} className="w-full bg-white border-2 border-gray-200 rounded-2xl py-3.5 font-bold text-sm flex items-center justify-center gap-2 disabled:opacity-50">
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                </svg>
                Continue with Google
              </button>
            )}
            <div className="flex justify-between text-xs pt-2">
              {authMode === 'login' ? (
                <>
                  <button onClick={() => setAuthMode('signup')} className="text-gray-500">Don't have account? Sign Up</button>
                  <button onClick={() => setAuthMode('forgot')} className="text-gray-500">Forgot Password?</button>
                </>
              ) : authMode === 'signup' ? (
                <button onClick={() => setAuthMode('login')} className="text-gray-500">Already have account? Login</button>
              ) : (
                <button onClick={() => setAuthMode('login')} className="text-gray-500">Back to Login</button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )

  const HomePage = () => {
    if (!user?.is_paid) {
      return (
        <PageContainer>
          <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
            <div className="text-7xl mb-6">🔒</div>
            <h2 className="text-2xl font-black text-gray-900 mb-2">Unlock Access</h2>
            <p className="text-sm text-gray-500 mb-6 max-w-xs">Pay 2,300 Fr to access all features</p>
            <div className="bg-white rounded-2xl p-5 border border-gray-100 w-full max-w-xs mb-4">
              <div className="text-2xl font-black text-gray-900">2,300 Fr</div>
              <div className="text-xs text-gray-500 mt-1">One-time payment</div>
            </div>
            <button onClick={() => navigate('deposit')} className="bg-gray-900 text-white rounded-2xl px-8 py-3.5 font-bold text-sm">Pay Now</button>
          </div>
        </PageContainer>
      )
    }
    return (
      <PageContainer>
        <div className="text-center mb-5">
          <div className="w-16 h-16 bg-gray-900 rounded-full flex items-center justify-center mx-auto mb-3 text-white text-xl font-black">{user?.name?.[0] || 'U'}</div>
          <h1 className="text-2xl font-black text-gray-900">Welcome! 👋</h1>
          <p className="text-gray-500 text-sm mt-1">@{user?.username}</p>
        </div>
        <div className="bg-white rounded-2xl p-4 mb-4 border border-gray-100">
          <div className="text-xs text-gray-400 font-medium mb-1">Available Balance</div>
          <div className="text-3xl font-black text-gray-900">{userCountry.symbol}{user?.balance?.toFixed(0) || 0}</div>
          <div className="text-xs text-gray-400 mt-1">Total Earnings: <span className="text-gray-700 font-medium">{userCountry.symbol}{user?.total_earnings?.toFixed(0) || 0}</span></div>
        </div>
        <div className="grid grid-cols-2 gap-3 mb-4">
          {[
            { icon: TrophyIcon, label: 'Earn Money', page: 'affiliate', color: 'bg-gray-900' },
            { icon: PlayIcon, label: 'Play Games', page: 'home', color: 'bg-gray-800' },
            { icon: VideoCameraIcon, label: 'Watch Videos', page: 'home', color: 'bg-gray-700' },
            { icon: BanknotesIcon, label: 'Instant Payout', page: 'withdraw', color: 'bg-gray-600' }
          ].map((item, i) => (
            <button key={i} onClick={() => navigate(item.page as Page)} className={`${item.color} text-white rounded-2xl p-4 text-center`}>
              <item.icon className="w-8 h-8 mx-auto mb-2" />
              <div className="text-xs font-bold">{item.label}</div>
            </button>
          ))}
        </div>
      </PageContainer>
    )
  }

  const DepositPage = () => (
    <PageContainer>
      <div className="flex items-center justify-between mb-4">
        <button onClick={() => navigate(user?.is_paid ? 'account' : 'home')} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-white"><ChevronLeftIcon className="w-6 h-6 text-gray-700" /></button>
        <h2 className="text-lg font-bold text-gray-900">{user?.is_paid ? 'Deposit' : 'Complete Payment'}</h2>
        <div className="w-10" />
      </div>
      <div className="bg-white rounded-2xl p-5 border border-gray-100">
        <div className="bg-amber-50 rounded-xl p-4 mb-4 text-center">
          <div className="text-3xl font-black text-gray-900">2,300 Fr</div>
          <div className="text-xs text-gray-600 mt-1">One-time access fee</div>
        </div>
        <div className="space-y-3 mb-4">
          <button onClick={() => setDepositMethod('chariow')} className={`w-full py-3 rounded-xl text-sm font-bold ${depositMethod === 'chariow' ? 'bg-amber-400 text-gray-900' : 'bg-gray-100 text-gray-600'}`}>💳 Chariow</button>
          <button onClick={() => setDepositMethod('manual')} className={`w-full py-3 rounded-xl text-sm font-bold ${depositMethod === 'manual' ? 'bg-amber-400 text-gray-900' : 'bg-gray-100 text-gray-600'}`}>📱 Manual Transfer</button>
        </div>
        {depositMethod === 'manual' && (
          <div className="space-y-3">
            <div className="bg-gray-50 rounded-xl p-3">
              <div className="text-xs font-bold text-gray-700 mb-2">Payment Details:</div>
              <div className="text-xs text-gray-600 space-y-1">
                <div><b>Bank:</b> Example Bank</div>
                <div><b>Account:</b> 1234567890</div>
                <div><b>Name:</b> EARNIZI LTD</div>
                <div><b>Reference:</b> EARN-{user?.referral_code}</div>
              </div>
            </div>
            <div>
              <label className="text-xs font-medium text-gray-600 block mb-2">Upload Payment Proof</label>
              <input type="file" accept="image/*" onChange={e => setProofFile(e.target.files?.[0] || null)} className="w-full text-xs" />
            </div>
          </div>
        )}
        <button onClick={handlePaymentSubmit} disabled={loadingState || (depositMethod === 'manual' && !proofFile)} className="w-full bg-gray-900 text-white rounded-2xl py-4 font-bold text-sm mt-4 disabled:opacity-50">
          {loadingState ? 'Processing...' : 'Submit Payment'}
        </button>
      </div>
    </PageContainer>
  )

  const SettingsPage = () => (
    <PageContainer>
      <div className="flex items-center gap-3 mb-4">
        <button onClick={() => navigate('account')} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-white"><ChevronLeftIcon className="w-6 h-6 text-gray-700" /></button>
        <h2 className="text-lg font-bold text-gray-900">Settings</h2>
        <div className="w-10" />
      </div>
      <div className="bg-white rounded-2xl p-4 mb-4 border border-gray-100">
        <h3 className="text-sm font-bold text-gray-900 mb-3">Language</h3>
        <div className="flex gap-2">
          <button onClick={() => setLang('en')} className={`flex-1 py-2 rounded-xl text-sm font-bold ${lang === 'en' ? 'bg-gray-900 text-white' : 'bg-gray-50 text-gray-500'}`}>English</button>
          <button onClick={() => setLang('fr')} className={`flex-1 py-2 rounded-xl text-sm font-bold ${lang === 'fr' ? 'bg-gray-900 text-white' : 'bg-gray-50 text-gray-500'}`}>Français</button>
        </div>
      </div>
      {pwaInstallable && (
        <div className="bg-white rounded-2xl p-4 mb-4 border border-gray-100">
          <h3 className="text-sm font-bold text-gray-900 mb-2">Install App</h3>
          <p className="text-xs text-gray-500 mb-3">Install EARNIZI on your device for quick access</p>
          <button onClick={handleInstallPWA} className="w-full bg-amber-400 text-gray-900 rounded-xl py-3 font-bold text-sm">Install App</button>
        </div>
      )}
      <div className="bg-white rounded-2xl border border-gray-100">
        <button onClick={() => navigate('editProfile')} className="w-full flex items-center gap-3 px-4 py-3.5 hover:bg-gray-50 text-left">
          <UserIcon className="w-5 h-5 text-gray-500" />
          <span className="text-sm font-medium text-gray-700 flex-1">Edit Profile</span>
          <ChevronLeftIcon className="w-4 h-4 text-gray-400 rotate-180" />
        </button>
      </div>
    </PageContainer>
  )

  const EditProfilePage = () => (
    <PageContainer>
      <div className="flex items-center gap-3 mb-4">
        <button onClick={() => navigate('settings')} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-white"><ChevronLeftIcon className="w-6 h-6 text-gray-700" /></button>
        <h2 className="text-lg font-bold text-gray-900">Edit Profile</h2>
        <div className="w-10" />
      </div>
      <div className="bg-white rounded-2xl p-4 border border-gray-100 space-y-3">
        <input type="text" value={profileForm.name} onChange={e => setProfileForm({...profileForm, name: e.target.value})} placeholder="Full Name" className="w-full bg-gray-50 rounded-xl py-2.5 px-3 text-sm outline-none border border-gray-100" />
        <input type="text" value={profileForm.username} onChange={e => setProfileForm({...profileForm, username: e.target.value})} placeholder="Username" className="w-full bg-gray-50 rounded-xl py-2.5 px-3 text-sm outline-none border border-gray-100" />
        <input type="tel" value={profileForm.phone} onChange={e => setProfileForm({...profileForm, phone: e.target.value})} placeholder="Phone" className="w-full bg-gray-50 rounded-xl py-2.5 px-3 text-sm outline-none border border-gray-100" />
        <select value={profileForm.country} onChange={e => setProfileForm({...profileForm, country: e.target.value})} className="w-full bg-gray-50 rounded-xl py-2.5 px-3 text-sm outline-none border border-gray-100">
          {COUNTRIES.map(c => <option key={c.code} value={c.code}>{c.name}</option>)}
        </select>
        <button onClick={handleProfileUpdate} disabled={loadingState} className="w-full bg-gray-900 text-white rounded-xl py-3 font-bold text-sm disabled:opacity-50">
          {loadingState ? 'Saving...' : 'Save Changes'}
        </button>
      </div>
    </PageContainer>
  )

  const AdminProductsPage = () => {
    if (!isAdmin) return <PageContainer><div className="text-center py-20 text-gray-500">Access Denied</div></PageContainer>
    const [selectedType, setSelectedType] = useState('')
    const [selectedCategory, setSelectedCategory] = useState('')
    
    return (
      <PageContainer>
        <div className="flex items-center gap-3 mb-4">
          <button onClick={() => navigate('adminPanel')} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-white"><ChevronLeftIcon className="w-6 h-6 text-gray-700" /></button>
          <h2 className="text-lg font-bold text-gray-900">Add Product</h2>
          <div className="w-10" />
        </div>
        <div className="bg-white rounded-2xl p-4 mb-4 border border-gray-100 space-y-3">
          <div>
            <label className="text-xs font-medium text-gray-600 block mb-2">Product Type *</label>
            <button onClick={() => setShowTypeSheet(true)} className="w-full bg-gray-50 rounded-xl py-3 px-4 text-sm text-left border border-gray-100 flex items-center justify-between">
              <span className={selectedType ? 'text-gray-900 font-medium' : 'text-gray-400'}>{selectedType ? PRODUCT_TYPES.find(t => t.value === selectedType)?.label : 'Select type...'}</span>
              <ChevronLeftIcon className="w-4 h-4 text-gray-400 rotate-90" />
            </button>
          </div>
          <input type="text" value={productForm.title} onChange={e => setProductForm({...productForm, title: e.target.value})} placeholder="Title *" className="w-full bg-gray-50 rounded-xl py-2.5 px-3 text-sm outline-none border border-gray-100" />
          <textarea value={productForm.description} onChange={e => setProductForm({...productForm, description: e.target.value})} placeholder="Description" rows={3} className="w-full bg-gray-50 rounded-xl py-2.5 px-3 text-sm outline-none border border-gray-100 resize-none" />
          <div>
            <label className="text-xs font-medium text-gray-600 block mb-2">Category *</label>
            <button onClick={() => setShowCategorySheet(true)} className="w-full bg-gray-50 rounded-xl py-3 px-4 text-sm text-left border border-gray-100 flex items-center justify-between">
              <span className={selectedCategory ? 'text-gray-900 font-medium' : 'text-gray-400'}>{selectedCategory ? CATEGORIES.find(c => c.value === selectedCategory)?.label : 'Select category...'}</span>
              <ChevronLeftIcon className="w-4 h-4 text-gray-400 rotate-90" />
            </button>
          </div>
          {selectedType === 'account' && (
            <div className="bg-purple-50 rounded-xl p-4 border border-purple-200">
              <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg p-3 mb-3 text-xs font-medium">ℹ️ Buyers receive one slot automatically on purchase</div>
              <div className="space-y-3">
                <input type="text" value={productForm.platform} onChange={e => setProductForm({...productForm, platform: e.target.value})} placeholder="Platform (e.g. Netflix, NordVPN)" className="w-full bg-white rounded-xl py-2.5 px-3 text-sm outline-none border border-purple-200" />
                <div className="grid grid-cols-2 gap-2">
                  <input type="text" value={productForm.cred1_label} onChange={e => setProductForm({...productForm, cred1_label: e.target.value})} placeholder="Field 1 label" className="bg-white rounded-xl py-2.5 px-3 text-sm outline-none border border-purple-200" />
                  <input type="text" value={productForm.cred2_label} onChange={e => setProductForm({...productForm, cred2_label: e.target.value})} placeholder="Field 2 label" className="bg-white rounded-xl py-2.5 px-3 text-sm outline-none border border-purple-200" />
                </div>
                <div className="space-y-2">
                  <div className="text-xs font-bold text-gray-700">Account Slots:</div>
                  {productForm.slots.map((slot, idx) => (
                    <div key={idx} className="bg-white rounded-xl p-3 border border-purple-200">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-bold text-purple-700">Slot {idx + 1}</span>
                        {productForm.slots.length > 1 && <button onClick={() => removeAccountSlot(idx)} className="text-red-500 text-xs">Remove</button>}
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <input type="text" value={slot.cred1} onChange={e => { const newSlots = [...productForm.slots]; newSlots[idx].cred1 = e.target.value; setProductForm({...productForm, slots: newSlots}) }} placeholder={productForm.cred1_label || 'Email'} className="bg-gray-50 rounded-lg py-2 px-2 text-xs outline-none border border-gray-200" />
                        <input type="text" value={slot.cred2} onChange={e => { const newSlots = [...productForm.slots]; newSlots[idx].cred2 = e.target.value; setProductForm({...productForm, slots: newSlots}) }} placeholder={productForm.cred2_label || 'Password'} className="bg-gray-50 rounded-lg py-2 px-2 text-xs outline-none border border-gray-200" />
                      </div>
                    </div>
                  ))}
                  <button onClick={addAccountSlot} className="w-full border-2 border-dashed border-purple-300 rounded-xl py-2.5 text-xs font-bold text-purple-700 hover:bg-purple-50">+ Add Account Slot</button>
                </div>
              </div>
            </div>
          )}
          <button onClick={() => { showToast('Product created'); setProductForm({ title: '', description: '', type: '', category: '', platform: '', cred1_label: 'Email', cred2_label: 'Password', slots: [{ cred1: '', cred2: '' }] }); setSelectedType(''); setSelectedCategory('') }} className="w-full bg-gray-900 text-white rounded-xl py-3 font-bold text-sm">Create Product</button>
        </div>
        {showTypeSheet && (
          <div className="fixed inset-0 z-[60] bg-black/50" onClick={() => setShowTypeSheet(false)}>
            <div className="absolute bottom-0 left-0 right-0 bg-gray-900 rounded-t-3xl p-4 max-h-[70vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
              <div className="w-12 h-1 bg-gray-700 rounded-full mx-auto mb-4" />
              <h3 className="text-white font-bold mb-4">Select Product Type</h3>
              <div className="space-y-2">
                {PRODUCT_TYPES.map(type => (
                  <button key={type.value} onClick={() => { setSelectedType(type.value); setProductForm({...productForm, type: type.value}); setShowTypeSheet(false) }} className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-gray-800 transition">
                    <span className="text-2xl">{type.icon}</span>
                    <span className="text-white text-sm font-medium flex-1 text-left">{type.label}</span>
                    <div className={`w-5 h-5 rounded-full border-2 ${selectedType === type.value ? 'border-amber-400 bg-amber-400' : 'border-gray-600'}`} />
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
        {showCategorySheet && (
          <div className="fixed inset-0 z-[60] bg-black/50" onClick={() => setShowCategorySheet(false)}>
            <div className="absolute bottom-0 left-0 right-0 bg-gray-900 rounded-t-3xl p-4 max-h-[70vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
              <div className="w-12 h-1 bg-gray-700 rounded-full mx-auto mb-4" />
              <h3 className="text-white font-bold mb-4">Select Category</h3>
              <div className="space-y-2">
                {CATEGORIES.map(cat => (
                  <button key={cat.value} onClick={() => { setSelectedCategory(cat.value); setProductForm({...productForm, category: cat.value}); setShowCategorySheet(false) }} className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-gray-800 transition">
                    <span className="text-2xl">{cat.icon}</span>
                    <span className="text-white text-sm font-medium flex-1 text-left">{cat.label}</span>
                    <div className={`w-5 h-5 rounded-full border-2 ${selectedCategory === cat.value ? 'border-amber-400 bg-amber-400' : 'border-gray-600'}`} />
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </PageContainer>
    )
  }

  const AdminPanelPage = () => {
    if (!isAdmin) return <PageContainer><div className="text-center py-20 text-gray-500">Access Denied</div></PageContainer>
    return (
      <PageContainer>
        <div className="flex items-center gap-3 mb-4">
          <button onClick={() => navigate('account')} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-white"><ChevronLeftIcon className="w-6 h-6 text-gray-700" /></button>
          <h2 className="text-lg font-bold text-gray-900">Admin Panel</h2>
          <div className="w-10" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          {[
            { page: 'adminProducts', icon: GiftIcon, label: 'Products', color: 'bg-gray-900' },
            { page: 'adminApiKeys', icon: ShieldCheckIcon, label: 'API Keys', color: 'bg-gray-800' },
            { page: 'adminApproveUsers', icon: UsersIcon, label: 'Approvals', color: 'bg-gray-700' },
          ].map(item => (
            <button key={item.page} onClick={() => navigate(item.page as Page)} className={`${item.color} text-white rounded-2xl p-4 text-center`}>
              <item.icon className="w-8 h-8 mx-auto mb-2" />
              <div className="text-xs font-bold">{item.label}</div>
            </button>
          ))}
        </div>
      </PageContainer>
    )
  }

  const AdminApiKeysPage = () => {
    if (!isAdmin) return <PageContainer><div className="text-center py-20 text-gray-500">Access Denied</div></PageContainer>
    const [rewardApiUrl, setRewardApiUrl] = useState('')
    const [rewardApiKey, setRewardApiKey] = useState('')
    const [rewardsEnabled, setRewardsEnabled] = useState(false)
    const [aiEndpoint, setAiEndpoint] = useState('')
    const [aiKey, setAiKey] = useState('')
    const [paymentTokens, setPaymentTokens] = useState({ 'MTN': 'MTN-REF-001', 'Orange': 'ORANGE-REF-001', 'Bank': 'BANK-REF-001', 'PayPal': 'PAYPAL-REF-001' })

    return (
      <PageContainer>
        <div className="flex items-center gap-3 mb-4">
          <button onClick={() => navigate('adminPanel')} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-white"><ChevronLeftIcon className="w-6 h-6 text-gray-700" /></button>
          <h2 className="text-lg font-bold text-gray-900">API Keys</h2>
          <div className="w-10" />
        </div>
        <div className="bg-white rounded-2xl p-4 mb-4 border border-gray-100">
          <h3 className="text-sm font-bold text-gray-900 mb-3">Rewards API (Rapido)</h3>
          <div className="space-y-3">
            <input type="url" value={rewardApiUrl} onChange={e => setRewardApiUrl(e.target.value)} placeholder="API Endpoint URL" className="w-full bg-gray-50 rounded-xl py-2.5 px-3 text-sm outline-none border border-gray-100" />
            <input type="password" value={rewardApiKey} onChange={e => setRewardApiKey(e.target.value)} placeholder="API Key" className="w-full bg-gray-50 rounded-xl py-2.5 px-3 text-sm outline-none border border-gray-100" />
            <div className="flex items-center justify-between">
              <span className="text-xs text-gray-600">Enable Rewards</span>
              <button onClick={() => setRewardsEnabled(!rewardsEnabled)} className={`w-10 h-5 rounded-full transition ${rewardsEnabled ? 'bg-green-500' : 'bg-gray-300'}`}>
                <div className={`w-4 h-4 bg-white rounded-full shadow transform transition ${rewardsEnabled ? 'translate-x-5' : 'translate-x-0.5'} mt-0.5`} />
              </button>
            </div>
            <button onClick={() => showToast('Rewards API saved')} className="w-full bg-gray-900 text-white rounded-xl py-2.5 text-sm font-bold">Save</button>
          </div>
        </div>
        <div className="bg-white rounded-2xl p-4 mb-4 border border-gray-100">
          <h3 className="text-sm font-bold text-gray-900 mb-3">AI Payment Verification</h3>
          <div className="space-y-3">
            <input type="url" value={aiEndpoint} onChange={e => setAiEndpoint(e.target.value)} placeholder="AI API Endpoint" className="w-full bg-gray-50 rounded-xl py-2.5 px-3 text-sm outline-none border border-gray-100" />
            <input type="password" value={aiKey} onChange={e => setAiKey(e.target.value)} placeholder="AI API Key" className="w-full bg-gray-50 rounded-xl py-2.5 px-3 text-sm outline-none border border-gray-100" />
            <button onClick={() => showToast('AI config saved')} className="w-full bg-gray-900 text-white rounded-xl py-2.5 text-sm font-bold">Save</button>
          </div>
        </div>
        <div className="bg-white rounded-2xl p-4 border border-gray-100">
          <h3 className="text-sm font-bold text-gray-900 mb-3">Payment Reference Tokens</h3>
          <p className="text-xs text-gray-500 mb-3">Define tokens for AI to verify payments</p>
          <div className="space-y-2">
            {Object.entries(paymentTokens).map(([method, token]) => (
              <div key={method} className="flex gap-2">
                <div className="flex-1 bg-gray-50 rounded-xl py-2 px-3 text-xs font-medium text-gray-700">{method}</div>
                <input type="text" value={token} onChange={e => setPaymentTokens({...paymentTokens, [method]: e.target.value})} className="flex-1 bg-gray-50 rounded-xl py-2 px-3 text-xs outline-none border border-gray-100" />
              </div>
            ))}
            <button onClick={() => showToast('Reference tokens saved')} className="w-full bg-gray-900 text-white rounded-xl py-2.5 text-sm font-bold mt-2">Save Tokens</button>
          </div>
        </div>
      </PageContainer>
    )
  }

  const AdminApproveUsersPage = () => {
    if (!isAdmin) return <PageContainer><div className="text-center py-20 text-gray-500">Access Denied</div></PageContainer>
    return (
      <PageContainer>
        <div className="flex items-center gap-3 mb-4">
          <button onClick={() => navigate('adminPanel')} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-white"><ChevronLeftIcon className="w-6 h-6 text-gray-700" /></button>
          <h2 className="text-lg font-bold text-gray-900">Pending Approvals</h2>
          <span className="bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">2</span>
        </div>
        <div className="space-y-3">
          {[
            { id: 'ap1', user: 'Jean D.', email: 'jean@test.com', amount: '2,300 Fr', method: 'MTN Mobile Money', proof: true },
            { id: 'ap2', user: 'Marie K.', email: 'marie@test.com', amount: '2,300 Fr', method: 'Bank Transfer', proof: true },
          ].map(a => (
            <div key={a.id} className="bg-white rounded-2xl p-4 border border-gray-100">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 bg-amber-100 rounded-full flex items-center justify-center text-sm font-bold text-amber-700">{a.user[0]}</div>
                <div><div className="text-sm font-bold text-gray-900">{a.user}</div><div className="text-xs text-gray-500">{a.email}</div></div>
              </div>
              <div className="text-xs text-gray-600 mb-2">{a.amount} • {a.method}</div>
              {a.proof && <div className="bg-gray-50 rounded-xl p-2 mb-3 text-xs text-gray-600">📎 Payment proof uploaded</div>}
              <div className="flex gap-2">
                <button onClick={() => handleAiCheck(a.id)} disabled={loadingState} className="flex-1 bg-purple-500 text-white rounded-xl py-2 text-xs font-bold disabled:opacity-50">🤖 AI Check</button>
                <button onClick={() => showToast('Approved')} className="flex-1 bg-green-500 text-white rounded-xl py-2 text-xs font-bold">Approve</button>
                <button onClick={() => showToast('Rejected')} className="flex-1 bg-red-500 text-white rounded-xl py-2 text-xs font-bold">Reject</button>
              </div>
            </div>
          ))}
        </div>
      </PageContainer>
    )
  }

  const ToastComponent = () => toast ? <div className="fixed top-20 left-4 right-4 z-50 bg-gray-900 text-white text-sm font-medium py-3 px-4 rounded-2xl shadow-lg">{toast}</div> : null

  const renderPage = () => {
    if (loading) return <div className="fixed inset-0 bg-gray-50 flex items-center justify-center"><div className="text-gray-500">Loading...</div></div>
    if (!user && page !== 'auth') return <AuthPage />
    switch (page) {
      case 'auth': return <AuthPage />
      case 'home': return <HomePage />
      case 'deposit': return <DepositPage />
      case 'settings': return <SettingsPage />
      case 'editProfile': return <EditProfilePage />
      case 'adminPanel': return <AdminPanelPage />
      case 'adminProducts': return <AdminProductsPage />
      case 'adminApiKeys': return <AdminApiKeysPage />
      case 'adminApproveUsers': return <AdminApproveUsersPage />
      default: return <HomePage />
    }
  }

  return (
    <AuthProvider>
      <div className="h-[100dvh] w-full bg-gray-50 overflow-hidden" style={{ fontFamily: 'system-ui, -apple-system, sans-serif' }}>
        {page !== 'auth' && <Drawer />}
        <TopBar />
        {user?.is_paid && <BottomTabs />}
        {renderPage()}
        <ToastComponent />
      </div>
    </AuthProvider>
  )
}

export default AppContent
