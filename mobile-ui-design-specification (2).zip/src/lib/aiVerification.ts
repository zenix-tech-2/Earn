import { supabase } from './supabase'

type AIVerificationResult = {
  confidence: number
  verified: boolean
  notes: string
  matchedReference?: string
}

export async function runAiCheck(paymentId: string): Promise<AIVerificationResult> {
  // Get payment details
  const { data: payment } = await supabase
    .from('pending_payments')
    .select('*')
    .eq('id', paymentId)
    .single()

  if (!payment) {
    return { confidence: 0, verified: false, notes: 'Payment not found' }
  }

  // Get admin AI config
  const { data: configs } = await supabase
    .from('admin_configs')
    .select('key, value')
    .in('key', ['ai_endpoint', 'ai_key'])

  const aiEndpoint = configs?.find(c => c.key === 'ai_endpoint')?.value || ''
  const aiKey = configs?.find(c => c.key === 'ai_key')?.value || ''

  if (!aiEndpoint || !aiKey) {
    // Fallback to demo logic if no AI configured
    return runDemoAiCheck(payment)
  }

  try {
    // Call AI API
    const response = await fetch(aiEndpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${aiKey}`
      },
      body: JSON.stringify({
        proof_url: payment.proof_url,
        amount: payment.amount,
        method: payment.method,
        reference_token: payment.reference_token
      })
    })

    const result = await response.json()
    return {
      confidence: result.confidence || 0,
      verified: result.verified || false,
      notes: result.notes || 'AI verification completed',
      matchedReference: result.matched_reference
    }
  } catch (error) {
    console.error('AI verification error:', error)
    return runDemoAiCheck(payment)
  }
}

// Demo AI check logic (fallback)
async function runDemoAiCheck(payment: any): Promise<AIVerificationResult> {
  // Get payment references for this method
  const { data: references } = await supabase
    .from('payment_references')
    .select('*')
    .eq('method', payment.method)
    .eq('is_active', true)

  if (!references || references.length === 0) {
    return { confidence: 0, verified: false, notes: 'No reference data for this payment method' }
  }

  // Simulate AI matching
  const hasProof = !!payment.proof_url
  const hasReference = !!payment.reference_token
  const amountMatches = payment.amount >= 2300

  let confidence = 0
  let notes = ''

  if (hasProof && hasReference && amountMatches) {
    // Check if reference token matches any known reference
    const matchedRef = references.find(ref => 
      payment.reference_token?.toLowerCase().includes(ref.reference_token.toLowerCase())
    )

    if (matchedRef) {
      confidence = 95
      notes = `High confidence match with reference: ${matchedRef.reference_token}`
    } else {
      confidence = 70
      notes = 'Proof uploaded but reference token not in database'
    }
  } else if (hasProof && amountMatches) {
    confidence = 60
    notes = 'Payment proof uploaded, amount matches, but no reference token'
  } else if (hasProof) {
    confidence = 45
    notes = 'Payment proof uploaded but amount does not match expected'
  } else {
    confidence = 20
    notes = 'No payment proof uploaded'
  }

  return {
    confidence,
    verified: confidence >= 85,
    notes,
    matchedReference: references[0]?.reference_token
  }
}

export async function autoApprovePayments() {
  // Get all pending payments
  const { data: pendingPayments } = await supabase
    .from('pending_payments')
    .select('*')
    .eq('status', 'pending')
    .eq('ai_verified', false)

  if (!pendingPayments) return

  for (const payment of pendingPayments) {
    const result = await runAiCheck(payment.id)
    
    // Update payment with AI results
    await supabase
      .from('pending_payments')
      .update({
        ai_confidence: result.confidence,
        ai_verified: result.verified,
        ai_notes: result.notes
      })
      .eq('id', payment.id)

    // Auto-approve if confidence >= 85%
    if (result.confidence >= 85) {
      await supabase
        .from('pending_payments')
        .update({
          status: 'approved',
          reviewed_at: new Date().toISOString()
        })
        .eq('id', payment.id)

      // Update user as paid
      await supabase
        .from('profiles')
        .update({ is_paid: true })
        .eq('id', payment.user_id)
    }
  }
}
