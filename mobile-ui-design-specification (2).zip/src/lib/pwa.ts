// PWA Installation Helper
let deferredPrompt: any = null

export function initPWA() {
  // Register service worker
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js')
        .then((registration) => {
          console.log('SW registered:', registration)
        })
        .catch((error) => {
          console.log('SW registration failed:', error)
        })
    })
  }

  // Capture install prompt
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault()
    deferredPrompt = e
    // Dispatch custom event to notify app
    window.dispatchEvent(new CustomEvent('pwa-installable'))
  })

  // Track installation
  window.addEventListener('appinstalled', () => {
    console.log('PWA installed')
    deferredPrompt = null
    window.dispatchEvent(new CustomEvent('pwa-installed'))
  })
}

export async function promptInstall(): Promise<boolean> {
  if (!deferredPrompt) {
    return false
  }

  deferredPrompt.prompt()
  const { outcome } = await deferredPrompt.userChoice
  
  if (outcome === 'accepted') {
    deferredPrompt = null
    return true
  }
  return false
}

export function isInstallable(): boolean {
  return deferredPrompt !== null
}

export function isStandalone(): boolean {
  return window.matchMedia('(display-mode: standalone)').matches ||
         (window.navigator as any).standalone === true
}
