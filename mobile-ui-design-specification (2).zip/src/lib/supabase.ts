import { createClient } from '@supabase/supabase-js'

const SUPABASE_URL = 'https://ypzcizmepyqyxmbkinzc.supabase.co'
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlwemNpem1lcHlxeXhtYmtpbnpjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA1NTk0NzMsImV4cCI6MjA5NjEzNTQ3M30.JVyuBgpg5Sjburtrn1ikKY9PCmXxtk1N1Ow4VhpU4bA'

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  }
})

export type User = {
  id: string
  email: string
  name?: string
  username?: string
  phone?: string
  country: string
  currency: string
  balance: number
  total_earnings: number
  is_admin: boolean
  is_paid: boolean
  referral_code: string
  referred_by_id?: string
  level1_count: number
  level2_count: number
  level3_count: number
  referral_clicks: number
  created_at: string
}

export type Product = {
  id: string
  title: string
  description?: string
  type?: string
  category?: string
  icon?: string
  is_free: boolean
  link?: string
  image_url?: string
  platform?: string
  cred1_label?: string
  cred2_label?: string
  created_at: string
}

export type AccountSlot = {
  id: string
  product_id: string
  slot_number: number
  credential1?: string
  credential2?: string
  is_assigned: boolean
  assigned_to?: string
  assigned_at?: string
}

export type PendingPayment = {
  id: string
  user_id: string
  amount: number
  method: string
  proof_url?: string
  reference_token?: string
  status: 'pending' | 'approved' | 'rejected'
  ai_confidence?: number
  ai_verified: boolean
  ai_notes?: string
  created_at: string
}

export type AdminConfig = {
  id: string
  key: string
  value: any
}

export type PaymentReference = {
  id: string
  method: string
  reference_token: string
  account_name?: string
  account_number?: string
  is_active: boolean
}

export type RewardConfig = {
  id: string
  name: string
  type: string
  api_endpoint?: string
  api_key?: string
  enabled: boolean
}
