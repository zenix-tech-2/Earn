import { supabase } from './supabase'

type RewardResult = {
  success: boolean
  amount?: number
  message: string
}

export async function checkVideoReward(userId: string, campaignId?: string): Promise<RewardResult> {
  // Get reward config
  const { data: config } = await supabase
    .from('reward_configs')
    .select('*')
    .eq('type', 'video')
    .eq('enabled', true)
    .single()

  if (!config || !config.api_endpoint) {
    // Demo mode - simulate reward
    return {
      success: true,
      amount: 1000,
      message: 'Video reward claimed! (Demo mode - API not configured)'
    }
  }

  try {
    const response = await fetch(config.api_endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${config.api_key || ''}`
      },
      body: JSON.stringify({
        user_id: userId,
        campaign_id: campaignId,
        action: 'video_watch'
      })
    })

    const result = await response.json()
    
    if (result.success) {
      // Update user balance
      await supabase.rpc('increment_user_balance', {
        user_id: userId,
        amount: result.amount || 1000
      })
    }

    return {
      success: result.success,
      amount: result.amount,
      message: result.message || 'Reward processed'
    }
  } catch (error) {
    console.error('Video reward API error:', error)
    return {
      success: false,
      message: 'Failed to process video reward'
    }
  }
}

export async function checkGameReward(userId: string, campaignId?: string, score?: number): Promise<RewardResult> {
  // Get reward config
  const { data: config } = await supabase
    .from('reward_configs')
    .select('*')
    .eq('type', 'game')
    .eq('enabled', true)
    .single()

  if (!config || !config.api_endpoint) {
    // Demo mode - simulate reward
    return {
      success: true,
      amount: 500,
      message: 'Game reward claimed! (Demo mode - API not configured)'
    }
  }

  try {
    const response = await fetch(config.api_endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${config.api_key || ''}`
      },
      body: JSON.stringify({
        user_id: userId,
        campaign_id: campaignId,
        action: 'game_complete',
        score: score || 0
      })
    })

    const result = await response.json()
    
    if (result.success) {
      // Update user balance
      await supabase.rpc('increment_user_balance', {
        user_id: userId,
        amount: result.amount || 500
      })
    }

    return {
      success: result.success,
      amount: result.amount,
      message: result.message || 'Reward processed'
    }
  } catch (error) {
    console.error('Game reward API error:', error)
    return {
      success: false,
      message: 'Failed to process game reward'
    }
  }
}
