# EARNIZI - Vercel Deployment & Setup Guide

## 📁 Project Structure
```
earnizi-app/
├── dist/                  ← Built files (deploy this to Vercel)
├── src/
│   ├── App.tsx           ← Main application
│   ├── i18n.ts           ← Translations (EN/FR)
│   ├── components/
│   │   └── icons.tsx     ← All icon components
│   ├── index.css         ← Tailwind CSS
│   └── main.tsx          ← Entry point
├── index.html
├── package.json
├── vite.config.ts
└── VERCEL_DEPLOYMENT_SETUP.md
```

---

## 🚀 DEPLOY TO VERCEL (3 Methods)

### Method 1: Vercel Dashboard (Easiest)

1. Go to https://vercel.com/new
2. Import your Git repository OR upload the `dist/` folder
3. **Framework Preset**: Select "Other"
4. **Root Directory**: Leave as `.` (or select the folder containing the `dist` folder)
5. **Build Command**: Leave empty (already built)
6. **Output Directory**: Set to `dist`
7. Click **Deploy**

Your app will be live at: `https://your-project.vercel.app`

To use your custom domain `earn.sellizi.store`:
- Go to **Settings → Domains**
- Add domain: `earn.sellizi.store`
- Update your DNS:
  - **Type**: A
  - **Name**: @
  - **Value**: `76.76.21.21` (Vercel IP)
  - **Type**: CNAME
  - **Name**: www
  - **Value**: cname.vercel-dns.com

---

### Method 2: Vercel CLI

```bash
# Install Vercel CLI
npm install -g vercel

# Login
vercel login

# Deploy
vercel --prod

# Set custom domain
vercel domains add earn.sellizi.store
```

---

### Method 3: Drag & Drop

1. Zip the `dist/` folder (rename to `earnizi.zip`)
2. Go to https://vercel.com/dashboard
3. Click **Add New → Project**
4. Drag & drop your ZIP file
5. Click **Deploy**

---

## ⚙️ INITIAL SETUP AFTER DEPLOYMENT

### Step 1: First Login as Admin
Use these demo credentials:
- **Email**: demo@earnizi.store
- **Password**: Any password (demo mode)
- This logs you in as **ADMIN**

### Step 2: Set Your Domain
1. Go to Vercel Dashboard → Your Project → Settings
2. Add custom domain: `earn.sellizi.store`
3. Update DNS at your domain registrar:
   ```
   A Record: @ → 76.76.21.21
   CNAME: www → cname.vercel-dns.com
   ```

---

## 🔧 ADMIN PANEL CONFIGURATION

### 1. Configure Chariow Payment
Navigate: **Admin → API Keys**

**Fill in:**
- **API Key**: `sk_49fc4x0l_225825b34aeaafcfab58690e01c127a2` ✅ (pre-configured)
- **Product ID**: `prod_earnizi_signup` ✅ (pre-configured)
- **Merchant ID**: Your Chariow merchant ID
- Click **Save Configuration**

### 2. Add Payment Methods (for Manual Payments)
Navigate: **Admin → Approve Users → Upload Reference**

**Add payment details for each method:**

#### For Manual Bank Transfer:
```
Bank Name: [Your Bank]
Account Name: [Account Name]
Account Number: [Account Number]
Swift/BIC: [If international]
Reference: BANK-REF-001
```

#### For Mobile Money (MTN/Orange):
```
Operator: MTN Mobile Money
Number: +234 XXX XXXX XXX
Reference: MTN-REF-001
```

#### For PayPal:
```
PayPal Email: your-paypal@email.com
Reference: PAYPAL-REF-001
```

**Upload these as reference images** in AI Settings for auto-verification.

### 3. Configure AI Payment Verification
Navigate: **Admin → AI Settings**

**Setup:**
1. Get AI API key from your AI service (e.g., OpenAI, Clarifai, etc.)
2. Enter **AI API Endpoint**: Your AI service URL
3. Enter **Admin API Key**: Your AI service key
4. Upload **reference images** for each payment method
5. Enable **Auto-approve valid payments** toggle
6. Click **Save Configuration**

**How AI Verification Works:**
- User uploads payment proof (screenshot)
- AI compares against reference images
- If match score > 90% → Auto-approve
- If uncertain → Stays for manual admin review

---

## 💰 PAYMENT SETUP

### Chariow Integration
The app already has your Chariow API key configured. To complete setup:

1. Log into Chariow dashboard
2. Create product: **"EARNIZI Access - 2300 Fr"**
3. Set Product ID: `prod_earnizi_signup`
4. Get your **Merchant ID** from Chariow
5. In Admin Panel → API Keys → Add Merchant ID
6. Save

### Manual Payment Flow
1. User selects **Manual Transfer**
2. Enters their payment details
3. Uploads proof screenshot
4. Admin receives notification
5. Admin verifies against reference
6. Admin clicks **Approve**
7. User gets access

---

## 🌍 CURRENCY CONFIGURATION

All 30 countries are pre-configured. The app auto-detects:
- User's country from signup
- Local currency symbol (₦, GH₵, KSh, CFA, etc.)
- Exchange rate (2300 Fr = $1 USD equivalent)

**To modify currencies:**
Edit `COUNTRIES` array in `src/App.tsx`
```javascript
{ code: 'NG', name: 'Nigeria', currency: 'NGN', symbol: '₦', rate: 2300 }
```

---

## 📱 AFFILIATE COMMISSION SETUP

**Current rates (configured in app):**
- Level 1 (Direct referral): **1000 points**
- Level 2 (2nd level): **500 points**
- Level 3 (3rd level): **300 points**

**To modify:**
Find in `src/App.tsx` → `AffiliatePage` component:
```javascript
<div className="text-lg font-black text-amber-700">1000</div>  // Level 1
<div className="text-lg font-black text-yellow-700">500</div>  // Level 2
<div className="text-lg font-black text-orange-700">300</div>  // Level 3
```

---

## 🔐 SECURITY SETUP

### Before Going Live:

1. **Change Demo Admin Account**
   - Currently: `demo@earnizi.store` / any password
   - Update in `src/App.tsx` → `handleLogin()` function

2. **Add Real Backend**
   - Currently using local state (demo mode)
   - Integrate Supabase/Firebase for:
     - User authentication
     - Database storage
     - File uploads
     - Payment webhooks

3. **Secure API Keys**
   - Move Chariow API key to environment variables
   - Never expose in client code
   - Use server-side API routes

4. **Enable HTTPS**
   - Vercel provides HTTPS automatically
   - Ensure `earn.sellizi.store` redirects to `https://earn.sellizi.store`

---

## 📊 ADMIN PANEL PAGES (15 Total)

1. **Dashboard** - Overview & quick stats
2. **User Management** - View all users
3. **Payment Settings** - Configure Chariow
4. **API Keys** - Chariow + AI API setup
5. **Product Management** - Add/edit/delete products
6. **Post Update** - Text/image updates
7. **Post Video** - Upload video content
8. **Post File** - Upload documents/files
9. **Post Link** - Share external links
10. **Account Login** - Platform credentials sharing
11. **Chat Management** - User messages
12. **Finance** - Revenue tracking
13. **Approve Users** - Payment approvals
14. **AI Settings** - Payment verification AI
15. **Campaigns** - Create/manage video/game tasks

---

## 🌐 LANGUAGE SWITCH

The app fully supports **English & French**:

**To translate any text:**
1. Open `src/i18n.ts`
2. Add key to both `en` and `fr` sections
3. Use in app: `tx('yourKey')`

**Example:**
```typescript
// In src/i18n.ts
en: { welcome: 'Welcome' },
fr: { welcome: 'Bienvenue' }

// In App.tsx
<h1>{tx('welcome')}</h1>
```

---

## 🔄 REWARDS GATING SYSTEM

**How it works:**
1. User signs up → Enter payment page
2. Pays 2300 Fr (local currency equivalent)
3. Admin approves (or AI auto-approves)
4. `isPaid: true` unlocks all features

**Locked features (until payment):**
- Affiliate program
- Products access
- Video rewards
- Game rewards
- Chat

**Unlocked after payment:**
- Everything including all pages

---

## 📦 FEATURES BREAKDOWN

### User Side:
✅ Sign up with country detection
✅ Multi-currency support (30 countries)
✅ 2300 Fr one-time payment
✅ Chariow + Manual payment
✅ Payment proof upload
✅ Affiliate links (3 levels: 1000/500/300)
✅ Referral tracking (clicks, registered, active)
✅ Video watch rewards (+1000 Fr)
✅ Game rewards (+500 Fr per win)
✅ Products download
✅ Chat with support
✅ Transaction history
✅ Withdraw (multiple methods)
✅ EN/FR language switch

### Admin Side:
✅ User management
✅ Payment approval
✅ AI payment verification setup
✅ Product management (all free)
✅ Content posting (video, file, link, image)
✅ Account login sharing
✅ Campaign creation
✅ Reward enable/disable
✅ Chat with users
✅ Revenue tracking
✅ API key management
✅ 15 admin pages

---

## 🛠️ TECHNICAL STACK

- **Frontend**: React 19 + TypeScript
- **Styling**: Tailwind CSS v4 (flat design, no shadows)
- **Build**: Vite 7
- **Icons**: Custom SVG (lightweight)
- **State**: React useState (local)
- **Deploy**: Vercel

---

## 🔄 PUSH UPDATES TO VERCEL

### After making changes:

```bash
# Build locally
npm run build

# Or deploy with Vercel CLI
vercel --prod

# Or connect Git repo for auto-deploy
# 1. Push to GitHub/GitLab
# 2. In Vercel: Settings → Git → Connect Repository
# 3. Auto-deploys on every push
```

---

## 📞 SUPPORT

**EARNIZI Support Channels:**
- Email: support@earn.sellizi.store
- WhatsApp: [Your number]
- Domain: https://earn.sellizi.store
- Admin: demo@earnizi.store (first access)

---

## ⚡ QUICK START CHECKLIST

- [ ] Deploy `dist/` folder to Vercel
- [ ] Add custom domain `earn.sellizi.store`
- [ ] Login as admin (demo@earnizi.store)
- [ ] Configure Chariow API (add Merchant ID)
- [ ] Upload payment reference images
- [ ] Setup AI payment verification (optional)
- [ ] Test payment flow with small amount
- [ ] Add real payment accounts in admin
- [ ] Create first admin post/video
- [ ] Add products to store
- [ ] Enable rewards (default: ON)
- [ ] Share app link with first users

---

## 🎯 NEXT STEPS

1. **Integrate Real Backend:**
   - Replace local state with Supabase/Firebase
   - Add real authentication
   - Store user data in database
   - File upload to cloud storage

2. **Payment Integration:**
   - Connect Chariow webhooks
   - Add payment status tracking
   - Email notifications

3. **AI Integration:**
   - Connect actual AI API (OpenAI Vision, etc.)
   - Train on your payment reference images
   - Set approval threshold

4. **Analytics:**
   - Add Vercel Analytics
   - Track user signups, payments, referrals
   - Monitor revenue

5. **Marketing:**
   - Add SEO meta tags
   - Social media preview images
   - Email signup form

---

## 📝 IMPORTANT NOTES

- **All products are FREE** (isFree: true by default)
- **2300 Fr is one-time payment** (not recurring)
- **Rewards can be paused** per campaign
- **Referral commissions** are tracked in "points" (Fr equivalent)
- **Currency auto-detected** from user's country
- **Admin demo mode** - replace with real auth before launch
- **Build output** in `/dist` folder is production-ready
- **No database** currently - using local state (demo)
- **File uploads** are simulated - add cloud storage for production

---

## 🎉 YOU'RE READY!

Deploy the `dist/` folder to Vercel and EARNIZI will be live at **https://earn.sellizi.store**

For questions, contact: dev@earn.sellizi.store
