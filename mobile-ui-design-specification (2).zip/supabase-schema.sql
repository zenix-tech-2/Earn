-- EARNIZI Supabase Database Schema
-- Copy this entire file to Supabase SQL Editor and run

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- Profiles table (extends auth.users)
create table public.profiles (
  id uuid references auth.users(id) on delete cascade primary key,
  email text unique not null,
  name text,
  username text unique,
  phone text,
  country text default 'NG',
  currency text default 'NGN',
  balance numeric default 0,
  total_earnings numeric default 0,
  is_admin boolean default false,
  is_paid boolean default false,
  referral_code text unique,
  referred_by_id uuid references public.profiles(id),
  level1_count integer default 0,
  level2_count integer default 0,
  level3_count integer default 0,
  referral_clicks integer default 0,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Products table
create table public.products (
  id uuid default gen_random_uuid() primary key,
  title text not null,
  description text,
  type text, -- ebook, file, social_account, source_code, course, other, account
  category text, -- Finance, Marketing, Social Media, Education, Technology, Other
  icon text,
  is_free boolean default true,
  link text,
  image_url text,
  platform text,
  cred1_label text,
  cred2_label text,
  created_at timestamptz default now(),
  created_by uuid references public.profiles(id)
);

-- Account slots (for account-type products)
create table public.account_slots (
  id uuid default gen_random_uuid() primary key,
  product_id uuid references public.products(id) on delete cascade,
  slot_number integer,
  credential1 text, -- Email
  credential2 text, -- Password
  is_assigned boolean default false,
  assigned_to uuid references public.profiles(id),
  assigned_at timestamptz,
  created_at timestamptz default now()
);

-- Categories
create table public.categories (
  id uuid default gen_random_uuid() primary key,
  name text unique not null,
  icon text,
  created_at timestamptz default now()
);

-- Transactions
create table public.transactions (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade,
  type text not null, -- deposit, withdraw, earn, payment
  amount numeric not null,
  status text default 'pending', -- pending, completed, rejected
  method text,
  reference text,
  proof_url text,
  ai_confidence numeric,
  ai_verified boolean default false,
  created_at timestamptz default now()
);

-- Pending approvals (for manual payment verification)
create table public.pending_payments (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade,
  amount numeric not null,
  method text not null,
  proof_url text,
  reference_token text,
  status text default 'pending', -- pending, approved, rejected
  ai_confidence numeric,
  ai_verified boolean default false,
  ai_notes text,
  reviewed_by uuid references public.profiles(id),
  reviewed_at timestamptz,
  created_at timestamptz default now()
);

-- Admin configs (API keys, settings)
create table public.admin_configs (
  id uuid default gen_random_uuid() primary key,
  key text unique not null,
  value jsonb,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Payment reference tokens (for AI verification)
create table public.payment_references (
  id uuid default gen_random_uuid() primary key,
  method text not null, -- MTN, Orange, Bank, etc.
  reference_token text not null,
  account_name text,
  account_number text,
  is_active boolean default true,
  created_at timestamptz default now()
);

-- Reward configs (Rapido API, etc.)
create table public.reward_configs (
  id uuid default gen_random_uuid() primary key,
  name text not null,
  type text not null, -- video, game
  api_endpoint text,
  api_key text,
  enabled boolean default false,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Chats
create table public.chats (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade,
  admin_id uuid references public.profiles(id),
  name text not null,
  last_message text,
  unread_count integer default 0,
  is_admin_chat boolean default false,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Messages
create table public.messages (
  id uuid default gen_random_uuid() primary key,
  chat_id uuid references public.chats(id) on delete cascade,
  sender_id uuid references public.profiles(id),
  content text not null,
  priority text, -- high, medium, low
  created_at timestamptz default now()
);

-- Campaigns (for video/game rewards)
create table public.campaigns (
  id uuid default gen_random_uuid() primary key,
  title text not null,
  description text,
  reward numeric not null,
  type text not null, -- video, game, task
  is_active boolean default true,
  created_at timestamptz default now()
);

-- User notifications
create table public.user_notifications (
  user_id uuid references public.profiles(id) on delete cascade primary key,
  notifications_enabled boolean default true,
  updated_at timestamptz default now()
);

-- RLS Policies
alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.account_slots enable row level security;
alter table public.categories enable row level security;
alter table public.transactions enable row level security;
alter table public.pending_payments enable row level security;
alter table public.admin_configs enable row level security;
alter table public.payment_references enable row level security;
alter table public.reward_configs enable row level security;
alter table public.chats enable row level security;
alter table public.messages enable row level security;
alter table public.campaigns enable row level security;
alter table public.user_notifications enable row level security;

-- Profiles policies
create policy "Users can view own profile" on public.profiles for select using (auth.uid() = id);
create policy "Users can update own profile" on public.profiles for update using (auth.uid() = id);
create policy "Admins can view all profiles" on public.profiles for select using (exists (select 1 from public.profiles where id = auth.uid() and is_admin = true));
create policy "Admins can update all profiles" on public.profiles for update using (exists (select 1 from public.profiles where id = auth.uid() and is_admin = true));

-- Products policies
create policy "Everyone can view products" on public.products for select using (true);
create policy "Admins can insert products" on public.products for insert with check (exists (select 1 from public.profiles where id = auth.uid() and is_admin = true));
create policy "Admins can update products" on public.products for update using (exists (select 1 from public.profiles where id = auth.uid() and is_admin = true));
create policy "Admins can delete products" on public.products for delete using (exists (select 1 from public.profiles where id = auth.uid() and is_admin = true));

-- Categories policies
create policy "Everyone can view categories" on public.categories for select using (true);
create policy "Admins can manage categories" on public.categories for all using (exists (select 1 from public.profiles where id = auth.uid() and is_admin = true));

-- Transactions policies
create policy "Users can view own transactions" on public.transactions for select using (auth.uid() = user_id);
create policy "Users can insert own transactions" on public.transactions for insert with check (auth.uid() = user_id);
create policy "Admins can view all transactions" on public.transactions for select using (exists (select 1 from public.profiles where id = auth.uid() and is_admin = true));

-- Pending payments policies
create policy "Users can view own pending payments" on public.pending_payments for select using (auth.uid() = user_id);
create policy "Users can insert own pending payments" on public.pending_payments for insert with check (auth.uid() = user_id);
create policy "Admins can view all pending payments" on public.pending_payments for select using (exists (select 1 from public.profiles where id = auth.uid() and is_admin = true));
create policy "Admins can update pending payments" on public.pending_payments for update using (exists (select 1 from public.profiles where id = auth.uid() and is_admin = true));

-- Admin configs policies
create policy "Admins can manage configs" on public.admin_configs for all using (exists (select 1 from public.profiles where id = auth.uid() and is_admin = true));

-- Payment references policies
create policy "Admins can manage payment references" on public.payment_references for all using (exists (select 1 from public.profiles where id = auth.uid() and is_admin = true));

-- Reward configs policies
create policy "Admins can manage reward configs" on public.reward_configs for all using (exists (select 1 from public.profiles where id = auth.uid() and is_admin = true));
create policy "Everyone can view active reward configs" on public.reward_configs for select using (enabled = true);

-- Chats policies
create policy "Users can view own chats" on public.chats for select using (auth.uid() = user_id or auth.uid() = admin_id);
create policy "Admins can view all chats" on public.chats for select using (exists (select 1 from public.profiles where id = auth.uid() and is_admin = true));

-- Messages policies
create policy "Users can view messages in own chats" on public.messages for select using (exists (select 1 from public.chats where id = chat_id and (user_id = auth.uid() or admin_id = auth.uid())));
create policy "Users can insert messages in own chats" on public.messages for insert with check (exists (select 1 from public.chats where id = chat_id and (user_id = auth.uid() or admin_id = auth.uid())));

-- Campaigns policies
create policy "Everyone can view active campaigns" on public.campaigns for select using (is_active = true);
create policy "Admins can manage campaigns" on public.campaigns for all using (exists (select 1 from public.profiles where id = auth.uid() and is_admin = true));

-- Functions and triggers

-- Auto-set admin for honestansah@gmail.com
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, name, is_admin, referral_code)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'name', split_part(new.email, '@', 1)),
    case when new.email = 'honestansah@gmail.com' then true else false end,
    'EAR-' || upper(substr(md5(random()::text), 1, 6))
  );
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Update updated_at timestamp
create or replace function public.handle_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create trigger handle_profiles_updated_at before update on public.profiles
  for each row execute function public.handle_updated_at();

create trigger handle_admin_configs_updated_at before update on public.admin_configs
  for each row execute function public.handle_updated_at();

create trigger handle_reward_configs_updated_at before update on public.reward_configs
  for each row execute function public.handle_updated_at();

-- Seed data
insert into public.categories (name, icon) values 
  ('Finance', '💰'),
  ('Marketing', '📈'),
  ('Social Media', '📱'),
  ('Education', '🎓'),
  ('Technology', '💻'),
  ('Other', '⭐')
on conflict do nothing;

insert into public.products (title, description, type, category, icon, is_free) values 
  ('Object-Oriented Programming in Python', 'Master OOP principles with practical Python examples. Covers classes, inheritance, polymorphism, and design patterns.', 'ebook', 'Technology', '📚', true),
  ('Web Development Bootcamp', 'Complete HTML, CSS, JavaScript course from scratch to deployment. Projects included.', 'course', 'Technology', '💻', true),
  ('Freelance Budgeting 101', 'Smart budgeting strategies for freelancers. Track income, manage expenses, plan for taxes.', 'ebook', 'Finance', '📊', true),
  ('Productivity Hacks for Developers', 'Boost your coding productivity with proven techniques and tools.', 'ebook', 'Productivity', '⚡', true),
  ('Cloud Architecture Guide', 'Design scalable cloud infrastructure. AWS, Azure, GCP best practices.', 'ebook', 'Technology', '☁', true),
  ('Mobile App Design Patterns', 'Common UI/UX patterns for iOS and Android apps. Includes code samples.', 'ebook', 'Technology', '📱', true)
on conflict do nothing;

insert into public.admin_configs (key, value) values 
  ('rewards_api_key', '""'),
  ('rewards_api_endpoint', '"https://api.rapido.com/rewards"'),
  ('ai_endpoint', '""'),
  ('ai_key', '""'),
  ('chariow_merchant_id', '""'),
  ('payment_reference_tokens', '["BANK-REF", "MTN-REF", "ORANGE-REF", "PAYPAL-REF"]'::jsonb)
on conflict (key) do nothing;

insert into public.payment_references (method, reference_token, account_name, account_number) values
  ('MTN Mobile Money', 'MTN-REF-001', 'EARNIZI LTD', '0244123456'),
  ('Orange Money', 'ORANGE-REF-001', 'EARNIZI LTD', '0500123456'),
  ('Bank Transfer', 'BANK-REF-001', 'EARNIZI LTD', '1234567890'),
  ('PayPal', 'PAYPAL-REF-001', 'EARNIZI LTD', 'payments@earn.sellizi.store')
on conflict do nothing;

insert into public.reward_configs (name, type, api_endpoint, api_key, enabled) values 
  ('Video Rewards API', 'video', 'https://api.rapido.com/rewards/video', '', false),
  ('Game Rewards API', 'game', 'https://api.rapido.com/rewards/game', '', false)
on conflict do nothing;

insert into public.campaigns (title, description, reward, type, is_active) values
  ('Watch 5 Videos', 'Watch sponsored videos to earn rewards', 2500, 'video', true),
  ('Puzzle Master', 'Complete puzzle level to earn', 1500, 'game', true),
  ('Daily Login', 'Login daily for 7 days', 1000, 'task', true)
on conflict do nothing;
